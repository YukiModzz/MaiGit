const axios = require("axios");
const yts = require("fast-yt-search");

function getYouTubeVideoId(url) {
	const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|v\/|embed\/|user\/[^\/\n\s]+\/)?(?:watch\?v=|v%3D|embed%2F|video%2F)?|youtu\.be\/|youtube\.com\/watch\?v=|youtube\.com\/embed\/|youtube\.com\/v\/|youtube\.com\/shorts\/|youtube\.com\/playlist\?list=)([a-zA-Z0-9_-]{11})/;
	const match = url.match(regex);
	return match ? match[1] : null;
}

const audio = [64,96,128,192,256,320,1000,1411]
const video = [360,480,720,1080,1440]

async function convert(id, quality) {
    try {
        const response = await axios.get(`https://ytdl.vreden.web.id/convert.php/${id}/${quality}`)
        
        let download;
        do {
            download = await axios.get(`https://ytdl.vreden.web.id/progress.php/${response.data.convert}`)
            if (download.data.status == "Error") return {
                status: false,
                message: "Progress error"
            }
        } while (download.data.status !== "Finished")
        
        return {
            status: true,
            quality: `${quality}${audio.includes(quality) ? "kbps" : "p"}`,
            availableQuality: audio.includes(quality) ? audio : video,
            url: download.data.url,
            filename: `${response.data.title} (${quality}${audio.includes(quality) ? "kbps).mp3" : "p).mp4"}`
        }
    } catch (error) {
        console.error("Converting error:", error)
        return {
            status: false,
            message: "Converting error"
        }
    }
}

async function ytmp3(link, formats = 128) {
	const videoId = getYouTubeVideoId(link);
	const format = audio.includes(Number(formats)) ? Number(formats) : 128
	if (!videoId) {
		return {
			status: false,
			message: "Invalid YouTube URL"
		};
	}
	try {
		let data = await yts("https://youtube.com/watch?v=" + videoId);
		let response = await convert(videoId, format)
		return {
			status: true,
			creator: "Yuki Modz",
			metadata: data.all[0],
			download: response
		};
	} catch (error) {
		console.log(error)
		return {
			status: false,
			message: error.response ? `HTTP Error: ${error.response.status}` : error.message
		};
	}
}

async function ytmp4(link, formats = 360) {
	const videoId = getYouTubeVideoId(link);
	const format = video.includes(Number(formats)) ? Number(formats) : 360
	if (!videoId) {
		return {
			status: false,
			message: "Invalid YouTube URL"
		};
	}
	try {
		let data = await yts("https://youtube.com/watch?v=" + videoId);
		let response = await convert(videoId, format)
		return {
			status: true,
			creator: "Yuki Modz",
			metadata: data.all[0],
			download: response
		};
	} catch (error) {
		console.log(error)
		return {
			status: false,
			message: error.response ? `HTTP Error: ${error.response.status}` : error.message
		};
	}
}

async function transcript(link) {
    try {
        const response = await axios.get('https://ytb2mp4.com/api/fetch-transcript', {
            params: {
                'url': link
            },
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36',
                'Referer': 'https://ytb2mp4.com/youtube-transcript'
            }
        });
        return {
            status: true,
            creator: "@vreden/youtube_scraper",
            transcript: response.data.transcript
        }
    } catch (error) {
        return {
            status: false,
            message: error.message
        }
    }
}

async function ytdlv2(link, formats = "default") {
    try {
        const result = await axios.get(`https://ytdl.vreden.web.id/metadata?url=${link}`)
        if (formats !== "default") {
            const videoId = getYouTubeVideoId(link);
            const isAudio = audio.includes(Number(formats))
            const isVideo = video.includes(Number(formats))
        	let format;
        	let response;
        	if (isAudio) {
        	    format = isAudio ? Number(formats) : 128
        	    response = await convert(videoId, format)
        	    result.data.downloads.audio = response.url
        	} else if (isVideo) {
        	    format = isVideo ? Number(formats) : 360
        	    response = await convert(videoId, format)
        	    result.data.downloads.video = response.url
        	}
    	}
        return {
            status: true,
            creator: "@vreden/youtube_scraper",
            ...result.data
        }
    } catch (error) {
        return {
            status: false,
            message: error.message
        }
    }
}

async function search(teks) {
	try {
		let data = await yts(teks);
		return {
			status: true,
			creator: "@vreden/youtube_scraper",
			results: data.all
		};
	} catch (error) {
		return {
			status: false,
			message: error.message
		};
	}
}

async function channel(teks) {
	try {
		let result = await axios.get(`https://ytdl.vreden.web.id/channel/${teks}`)
		return {
			status: true,
			creator: "@vreden/youtube_scraper",
			...result.data
		};
	} catch (error) {
		return {
			status: false,
			message: error.message
		};
	}
}

module.exports = {
	search,
	ytmp3,
	ytmp4,
	transcript,
	ytdlv2,
	channel
};